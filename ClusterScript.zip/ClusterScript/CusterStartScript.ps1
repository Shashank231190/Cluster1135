<#
  1. Create a schedule event in task schedular
  2. Start the network trace, netFt Trace, perfmon Trace & windows firewall Trace
  Copy Right : Shashank Aggarwal
#>

$credential = Get-Credential -Message "Enter the username & password"

$LogDirectory = "C:"
$logFolder = "MSTrace"
$logPath = $LogDirectory + "\" + $logFolder + "\"
$userName = $credential.UserName
$password = $credential.GetNetworkCredential().Password
$taskName = "cluster1135"
$profilerPath = "C:\ClusterScript\1135Profiler.xml"
$nameHost = hostname

if (-NOT(Test-Path -Path $LogDirectory"\"$logFolder)) {
    New-Item -Path $LogDirectory"\" -Name $logFolder -ItemType Directory -ErrorAction Stop
}


[scriptblock]$trace = {

    "Network Trace"
    netsh wfp cap start file= $logPath"wfpdiag.cab" 
    netsh trace start scenario=netconnection maxsize=1250 tracefile=$logPath$nameHost"_NetwotkTrace.etl" capture=yes report=no overwrite=yes 
    
    "Perf Trace"
    logman.exe delete perf
    Logman.exe create counter perf -o $logPath"Perfmon.blg" -f bincirc -v mmddhhmm -max 300 -c "\LogicalDisk( * )\*" "\Memory\*" "\Network Interface( * )\*" "\Paging File( * )\*" "\PhysicalDisk( * )\*" "\Processor( * )\*" "\Process( * )\*" "\Redirector\*" "\Server\*" "\System\*" "\iSCSI Request processing Time( * )\*"  -si 00:00:01
    logman.exe start perf
    
    "NetFT Trace"
    logman create trace "base_cluster" -ow -o $logPath"base_cluster.etl" -p `{7E66368D-B895-45F2-811F-FB37940421A6`} 0xffffffffffffffff 0xff -nb 16 16 -bs 512 -mode Circular -f bincirc -max 512 -ets
    
}


[scriptblock]$schedTask = {

    Register-ScheduledTask -Xml(get-content -Path $profilerPath | out-string) -TaskName $taskName -TaskPath "\Event Viewer Tasks\" -User $userName -Password $password -Force -ErrorAction stop
}

function get-SchedTask {

    $taskObj = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    return $taskObj.TaskName -eq $taskName
}


function start-Main {

    if (-NOT(get-SchedTask)) {
        .$schedTask
    }
    .$trace
    write-host -foregroundcolor green "Please close this window!"
}


start-Main

