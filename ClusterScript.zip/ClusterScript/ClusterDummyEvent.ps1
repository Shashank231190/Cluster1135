$LogDirectory = "C:"
$logFolder = "MSTrace"
$logPath = $LogDirectory + "\" + $logFolder + "\"

$nameHost = hostname

$dummyEvent = {
    write-eventlog -logname System -source "Microsoft-Windows-FailoverClustering"  -EntryType error -EventID 1135 -message "I am dummy event!"
    hostname
}

$nodes = (get-clusternode).Name


"starting task"
foreach($node in $nodes){
    $node
    if($node -eq $nameHost){
        continue
    }

    $result = invoke-command -ComputerName $node -ScriptBlock $dummyEvent
    Write-output "Command is successfull on node $result" | out-file -FilePath $logPath"\InvokeCommand.txt"

}


