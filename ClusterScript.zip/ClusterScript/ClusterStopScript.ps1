
$LogDirectory = "C:"
$logFolder = "MSTrace"
$ClusterScript = "C:\ClusterScript\ClusterDummyEvent.ps1"
$logPath = $LogDirectory + "\" + $logFolder + "\"
$nameHost = hostname

start-process powerShell.exe  $ClusterScript

[scriptBlock]$StopScript = {
    Logman.exe stop perf
    logman stop "base_cluster" -ets
    netsh wfp cap stop 
    Netsh trace stop
}

[scriptBlock]$EventLogs = {
    wevtutil epl System $logPath"System.evtx"
    wevtutil epl Application $logPath"Application.evtx"
    wevtutil epl Microsoft-Windows-SMBClient/Operational  $logPath"Smbclient.evtx"
    get-clusterlog -node $nameHost -Destination $logPath -uselocaltime
}


.$StopScript
.$EventLogs

$stopTime = Get-Date -Format HH:mm:ss | forEach-Object { $_ -replace ":", "_" }
$stopTime = "MSTrace_"+$stopTime
Set-Location $logPath
$items = Get-ChildItem -path  $logPath | where-object {$_.FullName -notLike "*MSTrace_*"}
new-item -path  $logpath -name $stopTime -ItemType Directory
$items | Move-Item  -Destination $stopTime -Force
Get-ScheduledTask -TaskName "Cluster1135" | Unregister-ScheduledTask -confirm:$false
logman delete perf





